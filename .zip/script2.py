import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from sktime.datasets import load_airline
from sktime.forecasting.model_selection import temporal_train_test_split
from sktime.performance_metrics.forecasting import smape_loss
from sktime import plot_ys

import os 
import predicto as pr 
#%%
# Import data 
url = "https://docs.google.com/spreadsheets/d/e/2PACX-1vQVtdpXMHB4g9h75a0jw8CsrqSuQmP5eMIB2adpKR5hkRggwMwzFy5kB-AIThodhVHNLxlZYm8fuoWj/pub?gid=2105854808&single=true&output=csv"
path_target = os.path.join(os.path.dirname(os.path.realpath(__file__)), "predicto", "data", "df_totem.csv")
df_totem_raw = pr.Load_db(url, path_target).save_as_df(path_target)
#%%
#plot data 
plt.figure(figsize=(17, 8))
plt.plot(df_totem_raw.Day_Total)
plt.title('Nombre de vélos par jour')
plt.ylabel('Nombre de vélos')
plt.xlabel('Datetime')
plt.grid(False)
plt.show()
#%%
##Specifying the forecasting task¶
##We can split the data as follows:

y_train, y_test = temporal_train_test_split(df_totem_raw, test_size=6)
plot_ys(y_train, y_test, labels=["y_train", "y_test"])
print(y_train.shape[0], y_test.shape[0])
#%%specify the forecasting horizon and pass that to our forecasting algorithm. 
fh = np.arange(1, len(y_test) + 1)  # we add 1 because the `stop` value is exclusive in `np.arange`
fh
#%%Let's start with two naïve forecasting strategies which can serve as references for comparison of more sophisticated approaches.
#We always predict the last value observed (in the training series),
#We predict the last value observed in the same season.

y_pred = np.repeat(y_train.iloc[-1], len(fh))
y_pred = pd.Series(y_pred, index=y_train.index[-1] + fh)

plot_ys(y_train, y_test, y_pred, labels=["y_train", "y_test", "y_pred"]);

# using sktime 
from sktime.forecasting.naive import NaiveForecaster

forecaster = NaiveForecaster(strategy="last")
forecaster.fit(y_train)
y_pred = forecaster.predict(fh)
plot_ys(y_train, y_test, y_pred, labels=["y_train", "y_test", "y_pred"]);
smape_loss(y_pred, y_test)

forecaster = NaiveForecaster(strategy="seasonal_last", sp=12)
forecaster.fit(y_train)
y_pred = forecaster.predict(fh)
plot_ys(y_train, y_test, y_pred, labels=["y_train", "y_test", "y_pred"])
smape_loss(y_pred, y_test)

##forcast 

y = df_totem_raw()
y_train, y_test = temporal_train_test_split(y, test_size=36)
print(y_train.shape[0], y_test.shape[0])


from sktime.forecasting.compose import ReducedRegressionForecaster
from sklearn.neighbors import KNeighborsRegressor

regressor = KNeighborsRegressor(n_neighbors=1)
forecaster = ReducedRegressionForecaster(regressor=regressor, window_length=12, strategy="recursive")
forecaster.fit(y_train)
y_pred = forecaster.predict(fh)
plot_ys(y_train, y_test, y_pred, labels=["y_train", "y_test", "y_pred"]);
smape_loss(y_test, y_pred)

from sktime.forecasting.model_selection import SlidingWindowSplitter
cv = SlidingWindowSplitter(window_length=10, start_with_window=True)
for input_window, output_window in cv.split(y_train.iloc[:20]):
    print(input_window, output_window)
    
##Statistical forecasters¶






#%%